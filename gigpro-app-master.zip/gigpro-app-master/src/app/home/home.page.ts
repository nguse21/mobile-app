import { Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';
import { StorageService } from '../providers/storage.service';
import { StorageTypes, UserType } from '../models/storage';
import { UserService } from '../providers/user.service';
import { BusinessService } from '../providers/business.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  loading = false;
  email = '';
  pass = '';
  constructor(
    private nav: NavController,
    private alert: AlertController,
    private userApi: UserService,
    private businessApi: BusinessService,
    private ss: StorageService) { }

  async ngOnInit() {
    const jwt = await this.ss.GetValue(StorageTypes.Jwt);
    const ut = await this.ss.GetValue(StorageTypes.UserType);
    if (jwt.Exists && ut.Exists) {
      if (ut.Value === UserType.User) {
        await this.nav.navigateRoot('freelancer');
      }
      if (ut.Value === UserType.Business) {
        await this.nav.navigateRoot('business');
      }
    }
  }

  async register() {
    await this.nav.navigateForward('register');
  }

  async login() {
    try {
      this.loading = true;
      const userStatus = await this.loginUser();
      let businessStatus = false;
      if (!userStatus) {
        businessStatus = await this.loginBusiness();
      }

      if (!userStatus && !businessStatus){
        throw new Error("Invalid creds");
      }
    } catch (err) {
      this.pass = '';
      const a = await this.alert.create({
        header: 'Unable to log in',
        message: "Please check your credentials",
        buttons: ['OK']
      });

      await a.present();
    } finally {
      this.loading = false;
    }
  }

  private async loginBusiness(): Promise<boolean> {
    try {
      this.loading = true;
      const jwt = await this.businessApi.AuthenticateBusiness(this.email, this.pass);
      await this.ss.SetValue(StorageTypes.Jwt, jwt);
      await this.ss.SetValue(StorageTypes.UserType, UserType.Business);
      await this.nav.navigateRoot('business');
      return true;
    } catch(err) {

    }

    return false;
  }

  private async loginUser(): Promise<boolean> {
    try {
      const jwt = await this.userApi.AuthenticateUser(this.email, this.pass);
      await this.ss.SetValue(StorageTypes.Jwt, jwt);
      await this.ss.SetValue(StorageTypes.UserType, UserType.Business);
      await this.nav.navigateRoot('freelancer');
      return true;
    } catch(err) {
      
    }

    return false;
  }

  async fBook() {
    const a = await this.alert.create({
      header: 'Error',
      message: "Not implemented",
      buttons: ['OK']
    });

    await a.present();
  }

  async google() {
    const a = await this.alert.create({
      header: 'Error',
      message: "Not implemented",
      buttons: ['OK']
    });

    await a.present();
  }

}
