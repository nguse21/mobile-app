import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: 'businessdash',
    component: HomePage,
    children: [
      {
        path: 'listings',
        loadChildren: () => import('../listings/listings.module').then(o => o.ListingsPageModule)
      },
      {
        path: 'account',
        loadChildren: () => import('../account/account.module').then(o => o.AccountPageModule)
      }
    ]
  },
  {
    path: '',
    redirectTo: 'businessdash/listings'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomePageRoutingModule { }
