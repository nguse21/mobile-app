import { Component, OnInit } from '@angular/core';
import { StorageService } from 'src/app/providers/storage.service';
import { NavController } from '@ionic/angular';
import { Business } from 'src/app/models/business';
import { StorageTypes } from 'src/app/models/storage';
import { BusinessService } from 'src/app/providers/business.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
})
export class AccountPage implements OnInit {

  business: Business;
  constructor(
    private ss: StorageService, 
    private nav: NavController,
    private businessApi: BusinessService) { }

  async ngOnInit() {
    this.business = JSON.parse((await this.ss.GetValue(StorageTypes.Business)).Value);
  }

  async logOut() {
    await this.ss.ClearAll();
    await this.nav.navigateRoot('', {animationDirection: 'back'});
  }

  async update() {
    await this.businessApi.UpdateBusiness(this.business);
    await this.ss.SetValue(StorageTypes.Business, JSON.stringify(this.business));
  }
}
