import { Component, OnInit, ViewChild } from '@angular/core';
import { JobListing } from 'src/app/models/business';
import { BusinessService } from 'src/app/providers/business.service';
import { AlertController, IonList, ToastController, NavController } from '@ionic/angular';
import { StorageService } from 'src/app/providers/storage.service';
import { StorageTypes } from 'src/app/models/storage';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-listings',
  templateUrl: './listings.page.html',
  styleUrls: ['./listings.page.scss'],
})
export class ListingsPage implements OnInit {
  @ViewChild('list', { static: true }) ionList: IonList;
  jobs = new Array<JobListing>();
  loading = false;

  constructor(
    private businessApi: BusinessService,
    private alert: AlertController,
    private ss: StorageService,
    private toast: ToastController,
    private route: ActivatedRoute,
    private nav: NavController
  ) {

    this.route.queryParams.subscribe(params => {
      if (params['listing']) {
        const listing = JSON.parse(params['listing']);
        if (listing) {
          // New listing
          const existingJob = this.jobs.find(o => o.Id === listing.Id);
          if (!existingJob) {
            this.jobs.push(listing);
          }
        }
      }
      if (params['removed']) {
        const id = params['removed'];
        const existingJob = this.jobs.find(o => o.Id === id);
        if (existingJob) {
          const index = this.jobs.indexOf(existingJob);
          this.jobs.splice(index, 1);
        }
      }
    });
  }

  async ngOnInit() {

  }

  async ionViewDidEnter() {
    try {
      const response = await Promise.all([
        this.businessApi.GetBusinessById(),
        this.businessApi.JobListingsByBusiness()
      ]);

      this.loading = true;
      const business = response[0];

      for (const j of response[1]) {
        const existingJob = this.jobs.find(o => o.Id === j.Id);
        if (!existingJob) {
          this.jobs.push(j);
        }
      }

      await this.ss.SetValue(StorageTypes.Business, JSON.stringify(business));

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  async delete(id: string) {
    this.ionList.closeSlidingItems();

    try {
      this.loading = true;
      await this.businessApi.DisableJobListing(id);

      const index = this.jobs.findIndex(o => o.Id === id);
      this.jobs.splice(index, 1);

      const toast = await this.toast.create({
        header: 'Listing removed',
        position: 'bottom',
        duration: 2000,
        color: 'danger',
      });

      await toast.present();

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  async updateListing(l: JobListing) {
    await this.ss.SetValue(StorageTypes.JobListing, JSON.stringify(l));
    await this.nav.navigateForward('updatelisting');
  }
}
