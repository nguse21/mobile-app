import { Component, OnInit } from '@angular/core';
import { AlertController, NavController, ToastController } from '@ionic/angular';
import { BusinessService } from 'src/app/providers/business.service';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { JobListing, BusinessLocation } from 'src/app/models/business';
import { NavigationExtras } from '@angular/router';
import { StorageService } from 'src/app/providers/storage.service';
import { StorageTypes } from 'src/app/models/storage';

@Component({
  selector: 'app-addlisting',
  templateUrl: './addlisting.page.html',
  styleUrls: ['./addlisting.page.scss'],
})
export class AddlistingPage implements OnInit {

  listingForm: FormGroup;
  locations = new Array<BusinessLocation>();
  loading = false;  

  constructor(
    private ss: StorageService,
    private businessApi: BusinessService,
    private nav: NavController,
    private alert: AlertController,
    private fb: FormBuilder,
    private toast: ToastController
  ) { }

  async ngOnInit() {
    this.listingForm = this.fb.group({
      helpType: ['', Validators.required],
      location: [''],
      startDate: ['', Validators.required],
      startTime: ['', Validators.required],
      rate: [''],
      employees: ['', [Validators.required, Validators.min(1)]],
      notes: [''],
    });

    const d = new Date();
    d.setDate(d.getDate() + 1);

    this.listingForm.get('employees').setValue("1");
    this.listingForm.get('startDate').setValue(d.toISOString());
    this.listingForm.get('startTime').setValue(d.toISOString());

    const storage = await this.ss.GetValue(StorageTypes.Business);
    const business = JSON.parse(storage.Value);

    // Add root location
    const loc: BusinessLocation = {
      Id: "",
      Address1: business.Address1,
      Address2: business.Address2,
      City: business.City,
      State: business.State,
      Zip: business.Zip,
      BusinessId: business.Id,
      IsEnabled: true,
    };

    this.locations.push(loc);
  }

  getFormValidationErrors() {
    Object.keys(this.listingForm.controls).forEach(key => {

      const controlErrors: ValidationErrors = this.listingForm.get(key).errors;
      if (controlErrors != null) {
        Object.keys(controlErrors).forEach(keyError => {
          console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
        });
      }
    });
  }

  async createListing() {
    try {
      const listing = new JobListing();
      listing.CreationDate = new Date();
      listing.JobType = this.listingForm.get('helpType').value;
      const date = this.listingForm.get('startDate').value;
      const time = new Date(this.listingForm.get('startTime').value);
      listing.Start = new Date(date);
      listing.Start.setDate(listing.Start.getDate() + 1);
      listing.Start.setHours(time.getHours());
      listing.Start.setMinutes(time.getMinutes());
      listing.End = new Date(); // Not really relevant right now
      listing.Location = this.listingForm.get('location').value;
      listing.Notes = this.listingForm.get('notes').value;
      listing.Employees = +this.listingForm.get('employees').value;

      const pay = this.listingForm.get('rate').value;
      listing.PayRangeStart = +(pay.lower * 100).toFixed(0);
      listing.PayRangeEnd = +(pay.upper * 100).toFixed(0);

      this.loading = true;
      listing.Id = await this.businessApi.CreateJobListing(listing);

      const navExtras: NavigationExtras = {
        queryParams: {
          listing: JSON.stringify(listing)
        }
      }

      await this.nav.navigateBack('business', navExtras);
      const toast = await this.toast.create({
        header: 'Listing created successfully',
        position: 'bottom',
        duration: 2000,
        color: 'success',
      });

      await toast.present();

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }
}
