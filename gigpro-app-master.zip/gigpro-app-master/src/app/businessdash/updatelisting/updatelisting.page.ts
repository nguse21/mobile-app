import { Component, OnInit } from '@angular/core';
import { BusinessService } from 'src/app/providers/business.service';
import { StorageService } from 'src/app/providers/storage.service';
import { JobListing, BusinessLocation } from 'src/app/models/business';
import { StorageTypes } from 'src/app/models/storage';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AlertController, ToastController, NavController } from '@ionic/angular';
import { NavigationExtras } from '@angular/router';
import { GlobalService } from 'src/app/providers/global.service';

@Component({
  selector: 'app-updatelisting',
  templateUrl: './updatelisting.page.html',
  styleUrls: ['./updatelisting.page.scss'],
})
export class UpdatelistingPage implements OnInit {

  listing: JobListing;
  listingForm: FormGroup;
  locations = new Array<BusinessLocation>();
  loading = false;
  payRange = {
    upper: 15,
    lower: 7
  }

  constructor(
    private ss: StorageService,
    private businessApi: BusinessService,
    private alert: AlertController,
    private fb: FormBuilder,
    private global: GlobalService,
    private toast: ToastController,
    private nav: NavController
  ) {
    this.listingForm = this.fb.group({
      helpType: ['', Validators.required],
      location: [''],
      startDate: ['', Validators.required],
      startTime: ['', Validators.required],
      rate: [''],
      employees: ['', [Validators.required, Validators.min(1)]],
      notes: [''],
    });
  }

  async ngOnInit() {
    let storage = await this.ss.GetValue(StorageTypes.JobListing);
    this.listing = JSON.parse(storage.Value);

    storage = await this.ss.GetValue(StorageTypes.Business);
    const business = JSON.parse(storage.Value);

    // Add root location
    const loc: BusinessLocation = {
      Id: "",
      Address1: business.Address1,
      Address2: business.Address2,
      City: business.City,
      State: business.State,
      Zip: business.Zip,
      BusinessId: business.Id,
      IsEnabled: true,
    };

    this.locations.push(loc);

    const start = new Date(this.listing.Start);

    this.listingForm.get('helpType').setValue(this.listing.JobType);
    this.listingForm.get('location').setValue(this.listing.Location);
    this.listingForm.get('employees').setValue(this.listing.Employees.toString());
    this.listingForm.get('startDate').setValue(start.toISOString());
    this.listingForm.get('startTime').setValue(start.toISOString());
    this.listingForm.get('notes').setValue(this.listing.Notes);
    this.payRange.lower = this.listing.PayRangeStart / 100;
    this.payRange.upper = this.listing.PayRangeEnd / 100;
  }

  async viewApps() {
    const alert = await this.alert.create({
      header: '',
      message: 'Coming Soon',
      buttons: ['OK']
    });

    await alert.present();
  }

  async updateListing() {
    try {
      this.loading = true;

      const navExtras: NavigationExtras = {
        queryParams: {
          listing: JSON.stringify(this.listing)
        }
      }

      await this.nav.navigateBack('business', navExtras);
      const toast = await this.toast.create({
        header: 'Listing updated',
        position: 'bottom',
        duration: 2000,
        color: 'success',
      });

      await toast.present();

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  async deleteConfirmed() {
    try {
      this.loading = true;
      await this.businessApi.DisableJobListing(this.listing.Id);

      const toast = await this.toast.create({
        header: 'Listing removed',
        position: 'bottom',
        duration: 2000,
        color: 'danger',
      });

      await toast.present();

      const navExtras: NavigationExtras = {
        queryParams: {
          removed: this.listing.Id
        }
      }

      await this.nav.navigateBack('business', navExtras);

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  async delete() {

    const alert = await this.alert.create({
      header: 'Delete Listing',
      message: 'Are you sure?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
          }
        }, {
          text: 'Yes',
          cssClass: 'danger',
          handler: async () => {
            await this.deleteConfirmed();
          }
        }
      ]
    });

    await alert.present();
  }
}
