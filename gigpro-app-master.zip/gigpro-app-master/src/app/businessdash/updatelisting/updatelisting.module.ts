import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdatelistingPageRoutingModule } from './updatelisting-routing.module';

import { UpdatelistingPage } from './updatelisting.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdatelistingPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [UpdatelistingPage]
})
export class UpdatelistingPageModule {}
