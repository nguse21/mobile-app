import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdatelistingPage } from './updatelisting.page';

const routes: Routes = [
  {
    path: '',
    component: UpdatelistingPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UpdatelistingPageRoutingModule {}
