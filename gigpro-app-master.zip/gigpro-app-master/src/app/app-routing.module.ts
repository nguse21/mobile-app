import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'freelancer',
    loadChildren: () => import('./freelancerdash/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'business',
    loadChildren: () => import('./businessdash/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'addlisting',
    loadChildren: () => import('./businessdash/addlisting/addlisting.module').then( m => m.AddlistingPageModule)
  },  
  {
    path: 'updatelisting',
    loadChildren: () => import('./businessdash/updatelisting/updatelisting.module').then( m => m.UpdatelistingPageModule)
  },  {
    path: 'appliedshiftdetails',
    loadChildren: () => import('./freelancerdash/appliedshiftdetails/appliedshiftdetails.module').then( m => m.AppliedshiftdetailsPageModule)
  },

  // {
  //   path: 'shiftdetails',
  //   loadChildren: () => import('./freelancerdash/shiftdetails/shiftdetails.module').then(o => o.ShiftdetailsPageModule)
  // },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  providers:[
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
