import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { FormGroup, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { UserService } from '../providers/user.service';
import { AlertController, NavController } from '@ionic/angular';
import { DatePicker } from '@ionic-native/date-picker/ngx';
import { StorageService } from '../providers/storage.service';
import { StorageTypes, UserType } from '../models/storage';
import { Business, RegisteredAgent } from '../models/business';
import { GlobalService } from '../providers/global.service';
import { BusinessService } from '../providers/business.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  loading = false;
  isUser = false;
  isBusiness = false;
  dob: any;

  userForm: FormGroup;
  businessForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private userApi: UserService,
    private businessApi: BusinessService,
    private alert: AlertController,
    private ss: StorageService,
    private nav: NavController,
    private global: GlobalService,
    private datePicker: DatePicker
  ) {

    this.userForm = this.fb.group({
      fName: ['', Validators.required],
      lName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      pass: ['', [Validators.required, Validators.min(4)]],
      phone: ['', [Validators.minLength(10), Validators.maxLength(11)]],
    });

    this.businessForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      pass: ['', [Validators.required, Validators.min(4)]],
      phone: ['', [Validators.minLength(10), Validators.maxLength(11)]],
      addr1: ['', Validators.required],
      addr2: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zip: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(5), Validators.pattern('^[0-9]*$')]],
      ein: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(10), Validators.pattern('^[0-9]*$')]],
      fName: ['', Validators.required],
      lName: ['', Validators.required],
      ssn: ['', [Validators.required, Validators.min(100000000), Validators.max(999999999), Validators.pattern('^[0-9]*$')]],
      dob: ['', Validators.required],
    });
  }

  ngOnInit() {

  }

  userSignup() {
    this.isUser = true;

    //  This is ridiculous
    const top = document.getElementById('top');
    if (top !== null) {
      top.scrollIntoView();
    }
  }

  businessSignup() {
    this.isBusiness = true;

    //  This is ridiculous
    const top = document.getElementById('top');
    if (top !== null) {
      top.scrollIntoView();
    }
  }

  async createBusiness() {
    try {
      const biz = new Business();
      biz.Agent = new RegisteredAgent();

      biz.Name = this.businessForm.get('name').value;
      biz.CreationDate = new Date();
      biz.Email = this.businessForm.get('email').value;
      biz.Password = this.businessForm.get('pass').value;
      biz.Phone = this.businessForm.get('phone').value;
      biz.Address1 = this.businessForm.get('addr1').value;
      biz.Address2 = this.businessForm.get('addr2').value;
      biz.City = this.businessForm.get('city').value;
      biz.State = this.businessForm.get('state').value;
      biz.Zip = this.businessForm.get('zip').value.toString();
      biz.EIN = this.businessForm.get('ein').value.toString();

      biz.Agent.FirstName = this.businessForm.get('fName').value;
      biz.Agent.LastName = this.businessForm.get('lName').value;
      biz.Agent.SSN = this.businessForm.get('ssn').value.toString();
      biz.Agent.DOB = this.businessForm.get('dob').value;

      const jwt = await this.businessApi.CreateBusiness(biz);
      await this.ss.SetValue(StorageTypes.Jwt, jwt);
      await this.ss.SetValue(StorageTypes.UserType, UserType.Business);
      await this.nav.navigateRoot('business');

    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

  async dobFocus() {
    if (this.global.IsMobileDevice()) {
      const d = document.getElementById("dob") as any;
      d.readOnly = true;

      const dob = await this.datePicker.show({
        date: new Date(1990, 1, 1),
        mode: 'date',
        allowFutureDates: false,
        androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
      });

      this.dob = this.formatDate(dob);
    }
  }

  async fBook() {
    const a = await this.alert.create({
      header: 'Error',
      message: "Not implemented",
      buttons: ['OK']
    });

    await a.present();
  }

  async google() {
    const a = await this.alert.create({
      header: 'Error',
      message: "Not implemented",
      buttons: ['OK']
    });

    await a.present();
  }

  formatDate(date) {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }

  async createUser() {
    try {
      this.loading = true;

      const user = new User();
      user.CreationDate = new Date();
      user.FirstName = this.userForm.get('fName').value;
      user.LastName = this.userForm.get('lName').value;
      user.Email = this.userForm.get('email').value;
      user.Password = this.userForm.get('pass').value;
      user.Phone = this.userForm.get('phone').value.toString();

      const jwt = await this.userApi.CreateUser(user);
      await this.ss.SetValue(StorageTypes.Jwt, jwt);
      await this.ss.SetValue(StorageTypes.UserType, UserType.User);
      await this.nav.navigateRoot('freelancer');
    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }
}
