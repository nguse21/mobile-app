import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { StorageTypes, GetStorageResponse } from '../models/storage';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private platform: Platform, private ns: NativeStorage) { }

  async GetValue(key: StorageTypes): Promise<GetStorageResponse> {
    var resp = new GetStorageResponse();
    resp.Exists = false;
    if (this.IsMobileDevice()) {
      const keys = await this.ns.keys() as string[];
      if (keys.find(o => o === key)) {
        resp.Exists = true;
        resp.Value = await this.ns.getItem(key);
      }
    } else {
      if (localStorage[key]) {
        resp.Exists = true;
        resp.Value = localStorage[key];
      }
    }

    return resp;
  }

  async SetValue(key: StorageTypes, value: string): Promise<any> {
    if (this.IsMobileDevice()) {
      await this.ns.setItem(key, value);
    } else {
      localStorage[key] = value;
    }
  }

  async ClearAll(): Promise<any> {
    if (this.IsMobileDevice()) {
      await this.ns.clear();
    } else {
      localStorage.clear();
    }
  }

  public IsMobileDevice() {
    return this.platform.is('mobile') && !this.platform.is('mobileweb');
  }
}
