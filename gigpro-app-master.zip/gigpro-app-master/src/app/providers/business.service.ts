import { Injectable } from '@angular/core';
import { GlobalService } from './global.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Business, JobListing } from '../models/business';
import { StorageService } from './storage.service';
import { StorageTypes } from '../models/storage';
import { NavController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class BusinessService {

  constructor(
    private http: HttpClient,
    private global: GlobalService,
    private ss: StorageService,
    private nav: NavController) { }

  async CreateBusiness(b: Business): Promise<string> {
    try {
      return await this.http.post(`${this.global.serverHost}/business`, b, { responseType: 'text' }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async UpdateBusiness(b: Business): Promise<any> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.patch(`${this.global.serverHost}/business/${b.Id}`, b, { headers: { Authorization: `Bearer ${jwt.Value}` }, responseType: 'text' }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async AuthenticateBusiness(email: string, pass: string): Promise<string> {
    try {
      return await this.http.post(`${this.global.serverHost}/business/authenticate`, { Email: email, Password: pass }, { responseType: 'text' }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async GetBusinessById(): Promise<Business> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.get<Business>(`${this.global.serverHost}/business`,
        { headers: { Authorization: `Bearer ${jwt.Value}` }}).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async CreateJobListing(job: JobListing): Promise<string> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.post(`${this.global.serverHost}/business/jobs`, job,
        { headers: { Authorization: `Bearer ${jwt.Value}` }, responseType: 'text' }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async JobListingsByBusiness(): Promise<JobListing[]> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.get<JobListing[]>(`${this.global.serverHost}/business/jobs`,
        { headers: { Authorization: `Bearer ${jwt.Value}` } }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async DisableJobListing(id: string): Promise<any> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.delete(`${this.global.serverHost}/business/jobs/${id}`,
        { headers: { Authorization: `Bearer ${jwt.Value}` } }).toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  handleError(e: HttpErrorResponse) {
    if (e.status === 401) {
      localStorage.clear();
      this.nav.navigateRoot('', {animationDirection: 'back'});
      throw new Error('Session Timeout');
    } else if (e.status === 418) {
      throw new Error(e.error);
    }
    else {
      throw e;
    }
  }
}
