import { Injectable } from '@angular/core';
import { isDevMode } from '@angular/core';
import { Platform } from '@ionic/angular';


@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  serverHost = "http://localhost:8080"
  // serverHost = "https://gigproinc.com"
  constructor(private platform: Platform) {
    if (!isDevMode()) {
      this.serverHost = "https://gigproinc.com";
      if (location.protocol === 'http:') {
        location.href = location.href.replace(/^http:/, 'https:')
      }
    }
  }

  IsMobileDevice() {
    return this.platform.is('mobile') && !this.platform.is('mobileweb');
  }

  AdjustForTimezone(date: Date): Date {
    var timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date
  }
}
