import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { GlobalService } from './global.service';
import { User, ListingsNearMeRequest, ApplicationRequest } from '../models/user';
import { JobListing, BusinessExt, Business } from '../models/business';
import { StorageTypes } from '../models/storage';
import { StorageService } from './storage.service';
import { NavController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: HttpClient,
    private global: GlobalService,
    private ss: StorageService,
    private nav: NavController
  ) { }

  async AuthenticateUser(email: string, pass: string): Promise<string> {
    try {
      return await this.http.post(`${this.global.serverHost}/user/authenticate`, { Email: email, Password: pass }, { responseType: 'text' }).toPromise();
    } catch (err) {
      throw err.error;
    }
  }

  async GetJobListingsNearMe(req: ListingsNearMeRequest): Promise<BusinessExt[]> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.post<BusinessExt[]>(`${this.global.serverHost}/user/jobs/nearme`,
        req,
        { headers: { Authorization: `Bearer ${jwt.Value}` } })
        .toPromise();
    } catch (err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async CreateUser(user: User): Promise<string> {
    try {
      return await this.http.post(`${this.global.serverHost}/user`, user, { responseType: 'text' }).toPromise();
    } catch (err) {
      throw err.error;
    }
  }

  async ApplyForJob(req: ApplicationRequest): Promise<any> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.post(`${this.global.serverHost}/user/jobs/${req.idJob}/apply`, req, { headers: { Authorization: `Bearer ${jwt.Value}` } }).toPromise();
    } catch(err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  async JobAppsByUser(): Promise<BusinessExt[]> {
    try {
      const jwt = await this.ss.GetValue(StorageTypes.Jwt);
      return await this.http.get<BusinessExt[]>(`${this.global.serverHost}/user/jobs/apply`, { headers: { Authorization: `Bearer ${jwt.Value}` } }).toPromise();
    } catch(err) {
      const httpErr = err as HttpErrorResponse;
      this.handleError(httpErr)
    }
  }

  handleError(e: HttpErrorResponse) {
    if (e.status === 401) {
      localStorage.clear();
      this.nav.navigateRoot('', {animationDirection: 'back'});
      throw new Error('Session Timeout');
    } else if (e.status === 418) {
      throw new Error(e.error);
    }
    else {
      throw e;
    }
  }
}
