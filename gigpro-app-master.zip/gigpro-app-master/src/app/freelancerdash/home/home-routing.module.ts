import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: 'freelancerdash',
    component: HomePage,
    children: [
      {
        path: 'listings',
        loadChildren: () => import('../listings/listings.module').then(o => o.ListingsPageModule)
      },
      {
        path: 'shifts',
        loadChildren: () => import('../shifts/shifts.module').then(o => o.ShiftsPageModule)
      },
      {
        path: 'account',
        loadChildren: () => import('../account/account.module').then(o => o.AccountPageModule)
      },
    ]
  },
  {
    path: '',
    redirectTo: 'freelancerdash/listings'
  },
  {
    path: 'shiftdetails',
    loadChildren: () => import('../shiftdetails/shiftdetails.module').then(o => o.ShiftdetailsPageModule)
  },
  {
    path: 'appliedshiftdetails',
    loadChildren: () => import('../appliedshiftdetails/appliedshiftdetails.module').then(o => o.AppliedshiftdetailsPageModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomePageRoutingModule { }
