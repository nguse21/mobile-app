import { Component, OnInit } from '@angular/core';
import { StorageService } from 'src/app/providers/storage.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  constructor(private ss: StorageService, private nav: NavController) { }

  ngOnInit() {
  }

  async logOut() {
    await this.ss.ClearAll();
    await this.nav.navigateRoot('', {animationDirection: 'back'});
  }

}
