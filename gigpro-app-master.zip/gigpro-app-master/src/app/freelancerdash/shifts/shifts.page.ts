import { Component, OnInit } from '@angular/core';
import { BusinessExt } from 'src/app/models/business';
import { UserService } from 'src/app/providers/user.service';
import { ToastController, NavController } from '@ionic/angular';
import { GlobalService } from 'src/app/providers/global.service';
import { StorageTypes } from 'src/app/models/storage';
import { StorageService } from 'src/app/providers/storage.service';

@Component({
  selector: 'app-shifts',
  templateUrl: './shifts.page.html',
  styleUrls: ['./shifts.page.scss'],
})
export class ShiftsPage implements OnInit {

  businesses: BusinessExt[];
  constructor(
    private userApi: UserService,
    private ss: StorageService,
    private nav: NavController
  ) { }

  async ngOnInit() {
    this.businesses = await this.userApi.JobAppsByUser();
  }

  async shiftDetails(id: string) {
    
    for (const b of this.businesses) {
      const currentShift = b.Listings.find(o => o.Id === id);
      if (currentShift) {
        await this.ss.SetValue(StorageTypes.SelectedShift, JSON.stringify(currentShift));
      }
    }    

    await this.nav.navigateForward('/freelancer/appliedshiftdetails');
  }
}
