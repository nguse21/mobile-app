import { Component, OnInit } from '@angular/core';
import { Platform, AlertController, NavController } from '@ionic/angular';
import { UserService } from 'src/app/providers/user.service';
import { BusinessExt } from 'src/app/models/business';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { StorageService } from 'src/app/providers/storage.service';
import { StorageTypes } from 'src/app/models/storage';

@Component({
  selector: 'app-listings',
  templateUrl: './listings.page.html',
  styleUrls: ['./listings.page.scss'],
})
export class ListingsPage implements OnInit {

  businesses: BusinessExt[];
  constructor(
    private gps: Geolocation,
    private api: UserService,
    private platform: Platform,
    private alert: AlertController,
    private nav: NavController,
    private ss: StorageService
  ) { }

  async ngOnInit() {
    if (this.platform.is('android') || this.platform.is('ios')) {
      const loc = await this.gps.getCurrentPosition()
      await this.getListings(loc.coords.latitude, loc.coords.longitude);
    } else {
      navigator.geolocation.getCurrentPosition(async pos => { 
        await this.getListings(pos.coords.latitude, pos.coords.longitude);
      }, err => {
        this.locationError();
      });
    }
  }

  async getListings(lat: number, lng: number) {
    const businesses = await this.api.GetJobListingsNearMe({
      Lat: lat,
      Lng: lng,
      SearchDistance: 50
    });

    await this.ss.SetValue(StorageTypes.HelpWantedBusinesses, JSON.stringify(businesses));

    // Server filters out listings that we've already applied for.  Kinda screwy
    this.businesses = businesses.filter(o => o.Listings && o.Listings.length > 0);    
  }

  async locationError() {
    const alert = await this.alert.create({
      header: 'Location error',
      message: 'Unable to get your current location.  This is the best way to provide you relevant listings available',
      buttons: ['OK']
    });

    await alert.present();
  }

  async shiftDetails(id: string) {
    
    for (const b of this.businesses) {
      const currentShift = b.Listings.find(o => o.Id === id);
      if (currentShift) {
        await this.ss.SetValue(StorageTypes.SelectedShift, JSON.stringify(currentShift));
      }
    }    

    await this.nav.navigateForward('/freelancer/shiftdetails');
  }
}
