import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { StorageService } from 'src/app/providers/storage.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
})
export class AccountPage implements OnInit {

  constructor(
    private ss: StorageService, 
    private nav: NavController) { }

  ngOnInit() {
  }
  
  async logOut() {
    await this.ss.ClearAll();
    await this.nav.navigateRoot('', {animationDirection: 'back'});
  }
}
