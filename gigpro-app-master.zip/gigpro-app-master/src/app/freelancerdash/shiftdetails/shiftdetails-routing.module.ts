import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShiftdetailsPage } from './shiftdetails.page';

const routes: Routes = [
  {
    path: '',
    component: ShiftdetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ShiftdetailsPageRoutingModule {}
