import { Component, OnInit } from '@angular/core';
import { JobListing, BusinessExt, BusinessLocation } from 'src/app/models/business';
import { StorageService } from 'src/app/providers/storage.service';
import { UserService } from 'src/app/providers/user.service';
import { StorageTypes } from 'src/app/models/storage';
import { AlertController, NavController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-shiftdetails',
  templateUrl: './shiftdetails.page.html',
  styleUrls: ['./shiftdetails.page.scss'],
})
export class ShiftdetailsPage implements OnInit {

  currentBusiness: BusinessExt;
  currentListing: JobListing;
  listingLocation: BusinessLocation;
  loading = false;
  minPay: number;
  maxPay: number;
  requestedPay: any;
  atBottom = false;

  constructor(
    private ss: StorageService,
    private api: UserService,
    private alert: AlertController,
    private nav: NavController,
    private toast: ToastController
  ) { }

  async ngOnInit() {
    this.currentListing = JSON.parse((await this.ss.GetValue(StorageTypes.SelectedShift)).Value) as JobListing;
    const businesses = JSON.parse((await this.ss.GetValue(StorageTypes.HelpWantedBusinesses)).Value) as BusinessExt[];
    this.currentBusiness = businesses.find(o => o.Id === this.currentListing.BusinessId);

    this.minPay = this.currentListing.PayRangeStart / 100;
    this.maxPay = this.currentListing.PayRangeEnd / 100;
    this.requestedPay = this.minPay;

    if (this.currentListing.Location === '') {
      this.listingLocation = {
        Address1: this.currentBusiness.Address1,
        Address2: this.currentBusiness.Address2,
        City: this.currentBusiness.City,
        State: this.currentBusiness.State,
        Zip: this.currentBusiness.Zip,
        BusinessId: this.currentBusiness.Id,
        Id: '',
        IsEnabled: true
      };
    }

    const content = document.getElementById('content');
    content.addEventListener('scroll', function (event) {
      debugger;
      const element = event.target as any;
      if (element.scrollHeight - element.scrollTop === element.clientHeight) {
        console.log('scrolled');
      }
    });
  }

  async apply() {
    if (this.loading) {
      return;
    }

    this.loading = true;
    try {
      await this.api.ApplyForJob({
        idJob: this.currentListing.Id,
        RequestedPay: +this.requestedPay
      });
      const toast = await this.toast.create({
        header: 'Your application has been submitted',
        position: 'bottom',
        duration: 2000,
        color: 'success',
      });

      await toast.present();
      this.nav.back();
    } catch (err) {
      const alert = await this.alert.create({
        header: 'Error',
        message: err,
        buttons: ['OK']
      });

      await alert.present();
    } finally {
      this.loading = false;
    }
  }

}
