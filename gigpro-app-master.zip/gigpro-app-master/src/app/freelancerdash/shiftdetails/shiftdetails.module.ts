import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShiftdetailsPageRoutingModule } from './shiftdetails-routing.module';

import { ShiftdetailsPage } from './shiftdetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ShiftdetailsPageRoutingModule
  ],
  declarations: [ShiftdetailsPage]
})
export class ShiftdetailsPageModule {}
