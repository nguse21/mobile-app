import { Component, OnInit } from '@angular/core';
import { BusinessExt, JobListing, BusinessLocation } from 'src/app/models/business';
import { StorageTypes } from 'src/app/models/storage';
import { StorageService } from 'src/app/providers/storage.service';
import { AlertController, ToastController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-appliedshiftdetails',
  templateUrl: './appliedshiftdetails.page.html',
  styleUrls: ['./appliedshiftdetails.page.scss'],
})
export class AppliedshiftdetailsPage implements OnInit {

  currentBusiness: BusinessExt;
  currentListing: JobListing;
  listingLocation: BusinessLocation;
  loading = false;
  constructor(
    private ss: StorageService,
    private alert: AlertController,
    private nav: NavController,
    private toast: ToastController
  ) { }

  async ngOnInit() {
    this.currentListing = JSON.parse((await this.ss.GetValue(StorageTypes.SelectedShift)).Value) as JobListing;
    const businesses = JSON.parse((await this.ss.GetValue(StorageTypes.HelpWantedBusinesses)).Value) as BusinessExt[];
    this.currentBusiness = businesses.find(o => o.Id === this.currentListing.BusinessId);

    if (this.currentListing.Location === '') {
      this.listingLocation = {
        Address1: this.currentBusiness.Address1,
        Address2: this.currentBusiness.Address2,
        City: this.currentBusiness.City,
        State: this.currentBusiness.State,
        Zip: this.currentBusiness.Zip,
        BusinessId: this.currentBusiness.Id,
        Id: '',
        IsEnabled: true
      };
    }
  }

  async withdraw() {
    if (this.loading) {
      return;
    }

    try {

    } catch(err) {

    } finally {
      this.loading = false;
    }
  }
}
