import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppliedshiftdetailsPage } from './appliedshiftdetails.page';

const routes: Routes = [
  {
    path: '',
    component: AppliedshiftdetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AppliedshiftdetailsPageRoutingModule {}
