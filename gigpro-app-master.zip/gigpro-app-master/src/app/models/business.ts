export class Business {
    Id: string;
    CreationDate: Date;
    Name: string;
    Email: string;
    Salt: string;
    Phone: string;
    Password: string;
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    EIN: string;
    Agent: RegisteredAgent;
    Description: string;
    IsEnabled: boolean;
}

export class BusinessExt extends Business {
    Listings: Array<JobListing>;
}

export class BusinessLocation {
    Id: string;
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    BusinessId: string;
    IsEnabled: boolean;
}

export class RegisteredAgent {
    FirstName: string;
    LastName: string;
    SSN: string;
    DOB: string;
}

export class JobListing {
    Id: string;
    CreationDate: Date;
    BusinessId: string;
    JobType: string;
    Start: Date;
    End: Date;
    Location: '';
    PayRangeStart: number;
    PayRangeEnd: number;
    Notes: string;
    Employees: number;
    IsEnabled: boolean;
}