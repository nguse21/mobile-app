export enum UserType {
    Business = 'business',
    User = 'user'
}

export enum StorageTypes {
    Jwt = 'jwt',
    UserType = 'usertype',
    Business = 'business',
    JobListing = 'joblisting',
    HelpWantedBusinesses = 'helpwantedbusinesses',
    SelectedShift = 'selectedshift'
}

export class GetStorageResponse {
    Exists: boolean;
    Value: string;
}