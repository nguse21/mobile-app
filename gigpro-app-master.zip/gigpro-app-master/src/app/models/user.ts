export class User {
    Id: string;
    CreationDate: Date;
    FirstName: string;
    LastName: string;
    Email: string;
    Password: string;
    Phone: string;
}

export class ListingsNearMeRequest {
    Lat: number;
    Lng: number;
    SearchDistance: number;
}

export class ApplicationRequest {
    idJob: string;
    RequestedPay: number;
}