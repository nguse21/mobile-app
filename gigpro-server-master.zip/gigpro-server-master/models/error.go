package models

type GigproError struct {
	Msg string
}

func (te GigproError) Error() string {
	return te.Msg
}

func NewSafeError(msg string) GigproError {
	te := GigproError{Msg: msg}
	return te
}
