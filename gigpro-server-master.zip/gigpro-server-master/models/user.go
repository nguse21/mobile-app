package models

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
	"time"
)

type User struct {
	Id           primitive.ObjectID `bson:"_id" json:"Id"`
	CreationDate time.Time          `bson:"CreationDate" json:"CreationDate"`
	FirstName    string             `bson:"FirstName" json:"FirstName"`
	LastName     string             `bson:"LastName" json:"LastName"`
	Email        string             `bson:"Email" json:"Email"`
	Password     string             `bson:"Password" json:"Password"`
	Salt         string             `bson:"Salt" json:"Salt"`
	Phone        string             `bson:"Phone" json:"Phone"`
	IsEnabled    bool               `bson:"IsEnabled" json:"IsEnabled"`
}

type AuthenticateRequest struct {
	Email    string `json:"Email"`
	Password string `json:"Password"`
}

type ListingsNearMeRequest struct {
	Lat            float64 `json:"Lat"`
	Lng            float64 `json:"Lng"`
	SearchDistance uint    `json:"SearchDistance"`
	IdUser         string  `json:"idUser"`
}

type ApplicationRequest struct {
	IdUser primitive.ObjectID `json:"idUser"`
	IdJob primitive.ObjectID `json:"idJob"`
	RequestedRate int `json:"RequestedRate"`
}