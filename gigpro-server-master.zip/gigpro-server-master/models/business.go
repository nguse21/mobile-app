package models

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
	"time"
)

type Business struct {
	Id              primitive.ObjectID `bson:"_id" json:"Id"`
	CreationDate    time.Time          `bson:"CreationDate" json:"CreationDate"`
	UpdatedDate     time.Time          `bson:"UpdatedDate" json:"UpdatedDate"`
	Name            string             `bson:"Name" json:"Name"`
	Email           string             `bson:"Email" json:"Email"`
	Phone           string             `bson:"Phone" json:"Phone"`
	Salt            string             `bson:"Salt" json:"Salt"`
	Password        string             `bson:"Password" json:"Password"`
	Address1        string             `bson:"Address1" json:"Address1"`
	Address2        string             `bson:"Address2" json:"Address2"`
	City            string             `bson:"City" json:"City"`
	State           string             `bson:"State" json:"State"`
	Zip             string             `bson:"Zip" json:"Zip"`
	EIN             string             `bson:"EIN" json:"EIN"`
	StripeAccountId string             `bson:"StripeAccountId" json:"-"`
	Agent           RegisteredAgent    `bson:"Agent" json:"Agent"`
	Latitude        float64            `bson:"Latitude" json:"Latitude"`
	Longitude       float64            `bson:"Longitude" json:"Longitude"`
	Description     string             `bson:"Description" json:"Description"`
	IsEnabled       bool               `bson:"IsEnabled" json:"IsEnabled"`
}

type BusinessExt struct {
	Business
	Listings []JobListing
}

type RegisteredAgent struct {
	FirstName string `bson:"FirstName" json:"FirstName"`
	LastName  string `bson:"LastName" json:"LastName"`
	SSN       string `bson:"SSN" json:"SSN"`
	DOB       string `bson:"DOB" json:"DOB"`
}

type JobListing struct {
	Id            primitive.ObjectID `bson:"_id" json:"Id"`
	CreationDate  time.Time          `bson:"CreationDate" json:"CreationDate"`
	BusinessId    primitive.ObjectID `bson:"BusinessId" json:"BusinessId"`
	JobType       string             `bson:"JobType" json:"JobType"`
	Start         time.Time          `bson:"Start" json:"Start"`
	End           time.Time          `bson:"End" json:"End"`
	Location      string             `bson:"Location" json:"Location"`
	Lat           float64            `bson:"Lat" json:"Lat"`
	Lng           float64            `bson:"Lng" json:"Lng"`
	PayRangeStart int                `bson:"PayRangeStart" json:"PayRangeStart"`
	PayRangeEnd   int                `bson:"PayRangeEnd" json:"PayRangeEnd"`
	Notes         string             `bson:"Notes" json:"Notes"`
	Employees     int                `bson:"Employees" json:"Employees"`
	Applicants    []JobApplicant     `bson:"Applicants" json:"Applicants"`
	IsEnabled     bool               `bson:"IsEnabled" json:"IsEnabled"`
}

type JobApplicant struct {
	UserId       primitive.ObjectID `bson:"UserId" json:"UserId"`
	CreationDate time.Time          `bson:"CreationDate" json:"CreationDate"`
	Hired        bool               `bson:"Hired" json:"Hired"`
}

type JobApplicantExt struct {
	JobApplicant
	ListingId primitive.ObjectID `bson:"ListingId" json:"ListingId"`
}
