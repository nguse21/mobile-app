package models

import (
	"encoding/json"
	"github.com/labstack/echo"
)

type CustomBinder struct{}

func (cb *CustomBinder) Bind(i interface{}, c echo.Context) error {

	decoder := json.NewDecoder(c.Request().Body)
	err := decoder.Decode(&i)

	return err
}
