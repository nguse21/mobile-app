package routes

import (
	impl "gigpro-server/implementation"
	"gigpro-server/models"
	"gigpro-server/utilities"
	"github.com/labstack/echo"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"net/http"
)

type Business struct {

}

func (b *Business) SetRoutes(e *echo.Echo) {
	g := e.Group("/business")
	g.Use(utilities.Jwt)

	e.POST("/business", func(c echo.Context) error {
		var business models.Business
		err := c.Bind(&business)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		_, jwt, err := impl.CreateBusiness(&business)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, jwt)
	})

	g.PATCH("/:idBusiness", func(c echo.Context) error {
		var business models.Business
		err := c.Bind(&business)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		id := c.Param("idBusiness")

		business.Id, err = primitive.ObjectIDFromHex(id)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		err = impl.UpdateBusiness(&business)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.NoContent(http.StatusOK)
	})

	e.POST("/business/authenticate", func(c echo.Context) error {
		var auth models.AuthenticateRequest
		err := c.Bind(&auth)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		jwt, err := impl.AuthenticateBusiness(auth.Email, auth.Password)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, jwt)
	})

	g.DELETE("/:idBusiness", func(c echo.Context) error {
		id := c.Param("idBusiness")

		err := impl.DisableBusiness(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.NoContent(http.StatusOK)
	})

	g.GET("/:idBusiness/jobs", func(c echo.Context) error {
		id := c.Param("idBusiness")

		jobs, err := impl.JobListingsByBusiness(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.JSON(http.StatusOK, jobs)
	})

	g.GET("/jobs", func(c echo.Context) error {
		id := c.Get("business").(string)

		jobs, err := impl.JobListingsByBusiness(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.JSON(http.StatusOK, jobs)
	})

	g.GET("", func(c echo.Context) error {
		id := c.Get("business").(string)

		business, err := impl.GetBusinessById(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.JSON(http.StatusOK, business)
	})

	g.POST("/jobs", func(c echo.Context) error {
		var job models.JobListing
		id := c.Get("business").(string)

		job.BusinessId, _ = primitive.ObjectIDFromHex(id)
		err := c.Bind(&job)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		jobId, err := impl.CreateJobListing(&job)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, jobId)
	})

	g.POST("/:idBusiness/jobs", func(c echo.Context) error {
		var job models.JobListing
		id := c.Param("idBusiness")

		err := c.Bind(&job)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		job.BusinessId, _ = primitive.ObjectIDFromHex(id)

		jobId, err := impl.CreateJobListing(&job)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, jobId)
	})

	g.DELETE("/jobs/:id", func(c echo.Context) error {
		id := c.Param("id")

		err := impl.DisableJobListing(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.NoContent(http.StatusOK)
	})
}
