package routes

import (
	impl "gigpro-server/implementation"
	"gigpro-server/models"
	"gigpro-server/utilities"
	"github.com/labstack/echo"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"net/http"
)

type User struct {

}

func (u *User) SetRoutes(e *echo.Echo) {
	g := e.Group("/user")
	g.Use(utilities.Jwt)

	e.POST("/user", func(c echo.Context) error {
		var user models.User
		err := c.Bind(&user)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		_, jwt, err := impl.CreateUser(&user)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, *jwt)
	})

	e.POST("/user/authenticate", func(c echo.Context) error {
		var auth models.AuthenticateRequest
		err := c.Bind(&auth)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		jwt, err := impl.AuthenticateUser(auth.Email, auth.Password)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.String(http.StatusOK, *jwt)
	})

	g.PATCH("/:idUser", func(c echo.Context) error {
		id := c.Param("idUser")

		err := impl.DisableUser(id)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.NoContent(http.StatusOK)
	})

	g.POST("/jobs/:id/apply", func(c echo.Context) error {
		var req models.ApplicationRequest
		err := c.Bind(&req)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		req.IdUser, _ = primitive.ObjectIDFromHex(c.Get("user").(string))
		err = impl.ApplyForJob(&req)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.NoContent(http.StatusOK)
	})

	g.GET("/jobs/apply", func(c echo.Context) error {
		businesses, err := impl.JobAppsByUser(c.Get("user").(string))
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.JSON(http.StatusOK, businesses)
	})

	g.POST("/jobs/nearme", func(c echo.Context) error {
		var req models.ListingsNearMeRequest
		err := c.Bind(&req)
		if err != nil {
			return c.NoContent(http.StatusBadRequest)
		}

		req.IdUser = c.Get("user").(string)
		listings, err := impl.GetJobListingsNearMe(&req)
		if err != nil {
			return c.String(utilities.SafeError(err))
		}

		return c.JSON(http.StatusOK, listings)
	})

}
