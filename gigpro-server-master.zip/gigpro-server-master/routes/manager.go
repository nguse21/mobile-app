package routes

import "github.com/labstack/echo"

type IRouteHandler interface {
	SetRoutes(e *echo.Echo)
}

func Setup(e *echo.Echo) {
	u := User{}
	b := Business{}

	u.SetRoutes(e)
	b.SetRoutes(e)
}
