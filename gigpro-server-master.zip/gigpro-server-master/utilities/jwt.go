package utilities

import (
	"github.com/dgrijalva/jwt-go"
	"github.com/labstack/echo"
	"net/http"
	"strings"
	"time"
)

func NewUserJwt(id string) (string, error) {

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"exp":  time.Now().AddDate(1, 0, 0).Unix(),
		"user": id,
	})

	return token.SignedString([]byte(secret))
}

func NewBusinessJwt(id string) (string, error) {

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"exp":  time.Now().AddDate(1, 0, 0).Unix(),
		"business": id,
	})

	return token.SignedString([]byte(secret))
}

func Jwt(next echo.HandlerFunc) echo.HandlerFunc {

	return func(c echo.Context) error {

		t := c.Request().Header.Get("Authorization")
		if !strings.Contains(t, "Bearer") {
			return c.String(http.StatusUnauthorized, "Unauthorized")
		}

		if len(t) < 10 {
			return c.String(http.StatusUnauthorized, "Unauthorized")
		}

		t = t[7:]

		token, err := jwt.Parse(t, func(token *jwt.Token) (interface{}, error) {
			return []byte(secret), nil
		})

		if err != nil {
			return c.String(http.StatusUnauthorized, err.Error())
		}

		if token != nil && token.Valid {

			c.Set("jwt", t)

			if claims, ok := token.Claims.(jwt.MapClaims); ok {

				if val, ok := claims["user"]; ok {
					id := val.(string)
					c.Set("user", id)
				}
				if val, ok := claims["business"]; ok {
					id := val.(string)
					c.Set("business", id)
				}
			}

			return next(c)
		}

		return c.String(http.StatusUnauthorized, "Unauthorized")
	}
}