package utilities

import (
	"context"
	"fmt"
	"github.com/palantir/stacktrace"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	"os"
	"time"
)

var dbClient *mongo.Client

func setupDb() error {
	host := os.Getenv("DBHost")
	if len(host) == 0 {
		host = "127.0.0.1"
	}

	var err error
	dbClient, err = mongo.NewClient(options.Client().ApplyURI(fmt.Sprintf("mongodb://%v:%v@%v:27017/?authSource=gigpro", "gigpro", "software", host)))
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)
	err = dbClient.Connect(ctx)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	err = dbClient.Ping(ctx, readpref.Primary())
	if err != nil {
		return stacktrace.Propagate(err, "")
	}
	return nil
}

func GetDBConnection() (*mongo.Database) {
	if dbClient == nil {
		err := setupDb()
		if err != nil {
			panic(err)
		}
	}

	db := dbClient.Database("gigpro")
	return db
}