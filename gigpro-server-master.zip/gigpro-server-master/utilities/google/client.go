package google

import (
	"context"
	"gigpro-server/models"
	"googlemaps.github.io/maps"
	"os"
)

type googleClient struct {
	client *maps.Client
}

func NewClient() (*googleClient, error) {

	client := googleClient{
		client: nil,
	}

	var err error
	client.client, err = maps.NewClient(maps.WithAPIKey(os.Getenv("googlemapsapi")))
	if err != nil {
		return nil, err
	}

	return &client, nil
}

func (c *googleClient) GeocodeAddress(addr string) (float64, float64, error) {
	result, err := c.client.Geocode(context.Background(), &maps.GeocodingRequest{
		Address:      addr,
	})
	if err != nil {
		return 0,0, err
	}

	if len(result) == 0 {
		return 0,0, models.NewSafeError("Unable to verify address")
	}

	return result[0].Geometry.Location.Lat, result[0].Geometry.Location.Lng, nil
}