package google

import "testing"

func TestGeocode (t *testing.T) {
	c, err := NewClient()
	if err != nil {
		panic(err)
	}

	_, _, err = c.GeocodeAddress("712 Glenmeadow St, River Falls, WI 54022")
	if err != nil {
		panic(err)
	}
}
