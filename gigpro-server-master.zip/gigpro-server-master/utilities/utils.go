package utilities

import (
	"fmt"
	"gigpro-server/models"
	"github.com/palantir/stacktrace"
	"math"
	"math/rand"
	"net/http"
	"time"
)

var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()123456789")
const secret = "7mg60N3RCbSUL6d"

func SafeError(payload interface{}) (int, string) {

	msg := "An error has occurred"
	status := http.StatusInternalServerError
	if err, ok := payload.(error); ok {
		rootErr := stacktrace.RootCause(err)
		if gigproErr, ok := rootErr.(models.GigproError); ok {
			msg = gigproErr.Error()
			status = http.StatusTeapot
		} else {
			// Bad error.  Do not return to client
			fmt.Println(err)
		}
	}

	return status, msg
}

func Seed() {
	rand.Seed(time.Now().Unix())
}

func RandomString(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}

func DistanceBetweenTwoPoints(lat1 float64, lng1 float64, lat2 float64, lng2 float64, unit ...string) float64 {
	const PI float64 = 3.141592653589793

	radlat1 := float64(PI * lat1 / 180)
	radlat2 := float64(PI * lat2 / 180)

	theta := float64(lng1 - lng2)
	radtheta := float64(PI * theta / 180)

	dist := math.Sin(radlat1) * math.Sin(radlat2) + math.Cos(radlat1) * math.Cos(radlat2) * math.Cos(radtheta)

	if dist > 1 {
		dist = 1
	}

	dist = math.Acos(dist)
	dist = dist * 180 / PI
	dist = dist * 60 * 1.1515

	if len(unit) > 0 {
		if unit[0] == "K" {
			dist = dist * 1.609344
		} else if unit[0] == "N" {
			dist = dist * 0.8684
		}
	}

	return dist
}