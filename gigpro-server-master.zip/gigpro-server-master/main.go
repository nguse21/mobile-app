package main

import (
	"gigpro-server/models"
	"gigpro-server/routes"
	"gigpro-server/utilities"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
	"github.com/stripe/stripe-go"
	"net/http"
	"os"
	"strconv"
)

func main() {
	production := os.Getenv("production")
	isProduction, _ := strconv.ParseBool(production)
	e := echo.New()

	stripe.Key = os.Getenv("GigproStripeKey")
	utilities.Seed()
	e.Binder = &models.CustomBinder{}

	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{"*"},
	}))

	e.Use(middleware.Recover())
	e.Use(utilities.NoCache())

	e.GET("/", func(c echo.Context) error {
		return c.String(http.StatusOK, "Gigpro")
	})

	routes.Setup(e)

	if !isProduction {
		e.Use(middleware.CORS())
		e.Logger.Fatal(e.Start(":8080"))
	} else {
		e.Static("/", "www")
		e.Logger.Fatal(e.Start(":8080"))
	}
}
