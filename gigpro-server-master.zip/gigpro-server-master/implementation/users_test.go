package implementation

import (
	"gigpro-server/models"
	"gigpro-server/utilities"
	"testing"
)

func TestCreateUser(t *testing.T) {
	pass := utilities.RandomString(10)
	user := models.User{
		FirstName: "Unit",
		LastName:  "Test",
		Email:     "unit@test.com",
		Password: pass,
		Phone:     "7157814987",
	}

	id, _, err := CreateUser(&user)
	if err != nil {
		panic(err)
	}

	_, err = AuthenticateUser(user.Email, pass)
	if err != nil {
		panic(err)
	}


	err = DisableUser(*id)
	if err != nil {
		panic(err)
	}
}
