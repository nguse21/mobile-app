package implementation

import (
	"gigpro-server/models"
	"gigpro-server/utilities"
	"github.com/stripe/stripe-go"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"os"
	"testing"
	"time"
)

func init() {
	utilities.Seed()
	stripe.Key = os.Getenv("GigproStripeKey")
	utilities.Seed()
}

func TestCRUDBusiness(t *testing.T) {
	pass := utilities.RandomString(25)
	biz := models.Business{
		Name:     "Unit Test",
		Email:    "test@unit.com",
		Salt:     "",
		Password: pass,
		Address1: "test test",
		Address2: "",
		City:     "test",
		State:    "WI",
		Zip:      "54022",
		EIN:      "41-1111111",
		Agent: models.RegisteredAgent{
			FirstName: "Unit",
			LastName:  "Test",
			SSN:       "111111111",
			DOB:       "10/27/1990",
		},
		IsEnabled: false,
	}

	id, _, err := CreateBusiness(&biz)
	if err != nil {
		panic(err)
	}

	_, err = AuthenticateBusiness(biz.Email, pass)
	if err != nil {
		panic(err)
	}

	bizId, _ := primitive.ObjectIDFromHex(id)
	job := models.JobListing{
		BusinessId:    bizId,
		Start:         time.Now().UTC(),
		End:           time.Now().UTC().AddDate(0, 0, 1),
		Location:      "",
		PayRangeStart: 1200,
		PayRangeEnd:   1600,
		Notes:         "Wear all black",
		Employees:     1,
		IsEnabled:     true,
	}

	jobId, err := CreateJobListing(&job)
	if err != nil {
		panic(err)
	}

	jobs, err := JobListingsByBusiness(bizId.Hex())
	if err != nil {
		panic(err)
	}

	found := false
	for i := range jobs {
		if jobs[i].Id.Hex() == jobId {
			found = true
			break
		}
	}

	if !found {
		panic("Unable to find job")
	}

	req := models.ListingsNearMeRequest{
		Lat:            44.865006,
		Lng:            -92.58083,
		SearchDistance: 50,
		IdUser:         UserId,
	}

	listings, err := GetJobListingsNearMe(&req)
	if err != nil {
		panic(err)
	}

	if len(listings) == 0 {
		panic("No listings found in 50 miles")
	}

	idUser, _ := primitive.ObjectIDFromHex(UserId)
	idJob, _ := primitive.ObjectIDFromHex(jobId)
	appReq := models.ApplicationRequest{
		IdUser: idUser,
		IdJob:  idJob,
	}

	err = ApplyForJob(&appReq)
	if err != nil {
		panic(err)
	}

	businesses, err := JobAppsByUser(UserId)
	if err != nil {
		panic(err)
	}

	found = false
	for i := range businesses {
		for t := range businesses[i].Listings {
			if businesses[i].Listings[t].Id.Hex() == jobId {
				found = true
			}
		}
	}

	if !found {
		t.Fatal("Unable to find applied job")
	}

	err = DisableJobListing(jobId)
	if err != nil {
		panic(err)
	}

	jobs, err = JobListingsByBusiness(bizId.Hex())
	if err != nil {
		panic(err)
	}

	found = false
	for i := range jobs {
		if jobs[i].Id.Hex() == jobId {
			found = true
			break
		}
	}

	if found {
		panic("Job was not disabled")
	}

	err = DisableBusiness(id)
	if err != nil {
		panic(err)
	}

}
