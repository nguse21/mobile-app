package implementation

import (
	"context"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"gigpro-server/models"
	"gigpro-server/utilities"
	"gigpro-server/utilities/google"
	"github.com/palantir/stacktrace"
	"github.com/stripe/stripe-go"
	account2 "github.com/stripe/stripe-go/account"
	"github.com/ttacon/libphonenumber"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"strings"
	"time"
)


func CreateJobListing(job *models.JobListing) (string, error) {
	job.IsEnabled = true
	job.CreationDate = time.Now().UTC()

	db := utilities.GetDBConnection()
	collection := db.Collection("jobs")

	gClient, err := google.NewClient()
	if err != nil {
		return "", stacktrace.Propagate(err, "")
	}

	if job.Location == "" {
		business, err := GetBusinessById(job.BusinessId.Hex())
		if err != nil {
			return "", stacktrace.Propagate(err, "")
		}

		job.Lat, job.Lng, err = gClient.GeocodeAddress(fmt.Sprintf("%v %v %v, %v, %v", business.Address1, business.Address2, business.City, business.State, business.Zip))
		if err != nil {
			return "", stacktrace.Propagate(err, "")
		}
	} else {
		return "", models.NewSafeError("Not implemented")
	}

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)
	job.Id = primitive.NewObjectID()

	_, err = collection.InsertOne(ctx, job)
	if err != nil {
		return "", stacktrace.Propagate(err, "")
	}

	//TODO:  Notify people nearby

	return job.Id.Hex(), nil
}

func JobListingsByBusiness(id string) ([]models.JobListing, error) {
	jobs := make([]models.JobListing, 0)
	bizId, _ := primitive.ObjectIDFromHex(id)

	db := utilities.GetDBConnection()
	collection := db.Collection("jobs")
	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	rows, err := collection.Find(ctx, bson.M{"BusinessId": bizId,
		"IsEnabled": true,  
		})

	defer rows.Close(ctx)

	if err == mongo.ErrNoDocuments {
		return jobs, nil
	}
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	for rows.Next(ctx) {
		var job models.JobListing
		err = rows.Decode(&job)
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		jobs = append(jobs, job)
	}

	return jobs, nil
}

func DisableJobListing(id string) error {
	db := utilities.GetDBConnection()
	collection := db.Collection("jobs")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	_, err = collection.UpdateOne(ctx, bson.M{"_id": objectId}, bson.D{
		{"$set", bson.D{
			{"IsEnabled", false},
		}},
	})

	return stacktrace.Propagate(err, "")
}

func UpdateBusiness(b *models.Business) error {
	b.UpdatedDate = time.Now().UTC()

	db := utilities.GetDBConnection()
	collection := db.Collection("business")
	ctx, _ := context.WithTimeout(context.Background(), 50*time.Second)

	_, err := collection.UpdateOne(ctx, bson.M{"_id": b.Id}, bson.D{
		{"$set", b},
	})

	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	return nil
}

func CreateBusiness(b *models.Business) (string, string, error) {
	b.Email = strings.ToLower(b.Email)
	b.IsEnabled = true
	b.CreationDate = time.Now().UTC()
	b.UpdatedDate = time.Now().UTC()

	b.Salt = utilities.RandomString(25)
	hash := sha1.New()
	bt := []byte(b.Password + b.Salt)
	_, err := hash.Write(bt)
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	b.Password = base64.URLEncoding.EncodeToString(hash.Sum(nil))

	db := utilities.GetDBConnection()
	collection := db.Collection("business")

	ctx, _ := context.WithTimeout(context.Background(), 50*time.Second)

	err = collection.FindOne(ctx, bson.M{"EIN": b.EIN, "IsEnabled": true}).Err()
	if err == nil {
		return "", "", stacktrace.Propagate(models.NewSafeError("Business is already registered"), "")
	}

	params := &stripe.AccountParams{
		Country: stripe.String("US"),
		Email: stripe.String(b.Email),
		RequestedCapabilities: []*string{
			stripe.String("transfers"),
		},
		Type: stripe.String("custom"),
	}

	account, err := account2.New(params)
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	b.StripeAccountId = account.ID

	mapsClient, err := google.NewClient()
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	b.Latitude, b.Longitude, err = mapsClient.GeocodeAddress(fmt.Sprintf("%v %v, %v %v %v", b.Address1, b.Address2, b.City, b.State, b.Zip))
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	b.Id = primitive.NewObjectID()
	_, err = collection.InsertOne(ctx, b)
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	jwt, err := utilities.NewBusinessJwt(b.Id.Hex())
	if err != nil {
		return "", "", stacktrace.Propagate(err, "")
	}

	return b.Id.Hex(), jwt, nil
}

func AuthenticateBusiness(email, password string) (string, error) {
	email = strings.ToLower(email)

	db := utilities.GetDBConnection()
	collection := db.Collection("business")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	var currentBusiness models.Business
	err := collection.FindOne(ctx, bson.M{"Email": email, "IsEnabled": true}).Decode(&currentBusiness)
	if err != nil {
		return "", stacktrace.Propagate(err, "")
	}

	hash := sha1.New()
	b := []byte(password + currentBusiness.Salt)
	_, err = hash.Write(b)
	if err != nil {
		return "", stacktrace.Propagate(err, "")
	}

	sha := base64.URLEncoding.EncodeToString(hash.Sum(nil))
	if currentBusiness.Password != sha {
		return "", stacktrace.Propagate(models.NewSafeError("Email or password is incorrect"), "")
	}

	jwt, err := utilities.NewBusinessJwt(currentBusiness.Id.Hex())
	if err != nil {
		return "", stacktrace.Propagate(err, "")
	}

	return jwt, nil
}

func GetBusinessById(id string) (*models.Business, error) {
	db := utilities.GetDBConnection()
	collection := db.Collection("business")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	var business models.Business
	err = collection.FindOne(ctx, bson.M{"_id": objectId}).Decode(&business)
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	phone, err := libphonenumber.Parse(business.Phone, "US")
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	business.Phone = libphonenumber.Format(phone, libphonenumber.NATIONAL)
	return &business, nil
}

func DisableBusiness(id string) error {
	db := utilities.GetDBConnection()
	collection := db.Collection("business")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	var business models.Business
	err = collection.FindOne(ctx, bson.M{"_id": objectId}).Decode(&business)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	//TODO verify if account is zeroed out
	_, err = account2.Del(business.StripeAccountId, nil)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	_, err = collection.UpdateOne(ctx, bson.M{"_id": objectId}, bson.D{
		{"$set", bson.D{
			{"IsEnabled", false},
		}},
	})

	return stacktrace.Propagate(err, "")
}
