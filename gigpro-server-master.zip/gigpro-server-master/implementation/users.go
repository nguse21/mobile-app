package implementation

import (
	"context"
	"crypto/sha1"
	"encoding/base64"
	"gigpro-server/models"
	"gigpro-server/utilities"
	"github.com/palantir/stacktrace"
	"github.com/ttacon/libphonenumber"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"strings"
	"time"
)

func CreateUser(user *models.User) (*string, *string, error) {

	user.Email = strings.ToLower(user.Email)
	user.IsEnabled = true
	user.Salt = utilities.RandomString(25)
	user.CreationDate = time.Now().UTC()

	hash := sha1.New()
	b := []byte(user.Password + user.Salt)
	_, err := hash.Write(b)
	if err != nil {
		return nil, nil, stacktrace.Propagate(err, "")
	}

	user.Password = base64.URLEncoding.EncodeToString(hash.Sum(nil))

	db := utilities.GetDBConnection()
	collection := db.Collection("users")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	err = collection.FindOne(ctx, bson.M{"Email": user.Email, "IsEnabled": true}).Err()
	if err == nil {
		return nil, nil, stacktrace.Propagate(models.NewSafeError("Email is already in use"), "")
	}

	user.Id = primitive.NewObjectID()
	res, err := collection.InsertOne(ctx, user)
	if err != nil {
		return nil, nil, stacktrace.Propagate(err, "")
	}

	id := res.InsertedID.(primitive.ObjectID).Hex()
	jwt, err := utilities.NewUserJwt(id)
	if err != nil {
		return nil, nil, stacktrace.Propagate(err, "")
	}

	return &id, &jwt, nil
}

func AuthenticateUser(email, password string) (*string, error) {
	email = strings.ToLower(email)

	db := utilities.GetDBConnection()
	collection := db.Collection("users")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	var currentUser models.User
	err := collection.FindOne(ctx, bson.M{"Email": email, "IsEnabled": true}).Decode(&currentUser)
	if err == mongo.ErrNoDocuments {
		return nil, stacktrace.Propagate(models.NewSafeError("Email or password is incorrect"), "")
	}

	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	hash := sha1.New()
	b := []byte(password + currentUser.Salt)
	_, err = hash.Write(b)
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	sha := base64.URLEncoding.EncodeToString(hash.Sum(nil))
	if currentUser.Password != sha {
		return nil, stacktrace.Propagate(models.NewSafeError("Email or password is incorrect"), "")
	}

	jwt, err := utilities.NewUserJwt(currentUser.Id.Hex())
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	return &jwt, nil
}

func DisableUser(id string) error {
	db := utilities.GetDBConnection()
	collection := db.Collection("users")

	ctx, _ := context.WithTimeout(context.Background(), 5*time.Second)

	objectId, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	_, err = collection.UpdateOne(ctx, bson.M{"_id": objectId}, bson.D{
		{"$set", bson.D{
			{"IsEnabled", false},
		}},
	})

	return stacktrace.Propagate(err, "")
}

func JobAppsByUser(id string) ([]models.BusinessExt, error) {
	response := make([]models.BusinessExt, 0)

	db := utilities.GetDBConnection()
	collection := db.Collection("jobapplicants")
	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)

	userId, _ := primitive.ObjectIDFromHex(id)

	jobIds := make([]primitive.ObjectID, 0)
	res, err := collection.Find(ctx, bson.M{"jobapplicant.UserId": userId})
	defer res.Close(ctx)
	if err == mongo.ErrNoDocuments {
		return response, nil
	}
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	for res.Next(ctx) {
		var tmp models.JobApplicantExt
		err = res.Decode(&tmp)
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		jobIds = append(jobIds, tmp.ListingId)
	}

	jobs := make([]models.JobListing, 0)
	businessIds := make([]primitive.ObjectID, 0)
	collection = db.Collection("jobs")
	res, err = collection.Find(ctx, bson.M{"_id": bson.M{"$in": jobIds}, "IsEnabled": true})
	defer res.Close(ctx)
	if err == mongo.ErrNoDocuments {
		return response, nil
	}
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	for res.Next(ctx) {
		var tmp models.JobListing
		err = res.Decode(&tmp)
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		jobs = append(jobs, tmp)
		businessIds = append(businessIds, tmp.BusinessId)
	}

	collection = db.Collection("business")
	res, err = collection.Find(ctx, bson.M{"_id": bson.M{"$in": businessIds}, "IsEnabled": true})
	defer res.Close(ctx)
	if err == mongo.ErrNoDocuments {
		return response, nil
	}
	if err != nil {
 		return nil, stacktrace.Propagate(err, "")
	}

	for res.Next(ctx) {
		var business models.BusinessExt
		err = res.Decode(&business.Business)
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		phone, err := libphonenumber.Parse(business.Phone, "US")
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		business.Phone = libphonenumber.Format(phone, libphonenumber.NATIONAL)

		response = append(response, business)
	}

	for i := range response {
		for t := range jobs {
			if response[i].Id.Hex() == jobs[t].BusinessId.Hex() {
				response[i].Listings = append(response[i].Listings, jobs[t])
			}
		}
	}

	return response, nil
}

func ApplyForJob(req *models.ApplicationRequest) error {
	db := utilities.GetDBConnection()
	collection := db.Collection("jobs")
	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)

	var job models.JobListing
	err := collection.FindOne(ctx, bson.M{"_id": req.IdJob}).Decode(&job)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	hireCount := 0
	for i := range job.Applicants {
		if job.Applicants[i].UserId == req.IdUser {
			return stacktrace.Propagate(models.NewSafeError("You have already applied for job"), "")
		}

		if job.Applicants[i].Hired {
			hireCount++
		}
	}

	if hireCount >= job.Employees {
		return stacktrace.Propagate(models.NewSafeError("Sorry, this position has already been filled"), "")
	}

	applicant := models.JobApplicant{
		UserId:       req.IdUser,
		CreationDate: time.Now().UTC(),
		Hired:        false,
	}

	applicantExt := models.JobApplicantExt{
		JobApplicant: applicant,
		ListingId:    req.IdJob,
	}

	job.Applicants = append(job.Applicants, applicant)

	_, err = collection.UpdateOne(ctx, bson.M{"_id": req.IdJob}, bson.D{
		{"$set", bson.D{
			{"Applicants", job.Applicants},
		}},
	})
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	collection = db.Collection("jobapplicants")
	_, err = collection.InsertOne(ctx, &applicantExt)
	if err != nil {
		return stacktrace.Propagate(err, "")
	}

	return nil
}

func GetJobListingsNearMe(req *models.ListingsNearMeRequest) ([]models.BusinessExt, error) {
	response := make([]models.BusinessExt, 0)

	db := utilities.GetDBConnection()
	collection := db.Collection("jobs")
	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)

	var jobs []models.JobListing
	rows, err := collection.Find(ctx, bson.M{"IsEnabled": true})
	defer rows.Close(ctx)
	if err == mongo.ErrNoDocuments {
		return response, nil
	}
	if err != nil {
		return nil, stacktrace.Propagate(err, "")
	}

	for rows.Next(ctx) {
		var job models.JobListing
		err = rows.Decode(&job)
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		miles := utilities.DistanceBetweenTwoPoints(job.Lat, job.Lng, req.Lat, req.Lng)
		if miles <= float64(req.SearchDistance) {
			jobs = append(jobs, job)
		}
	}

	if len(jobs) > 0 {
		ids := make([]primitive.ObjectID, len(jobs))
		for i := range jobs {
			ids[i] = jobs[i].BusinessId
		}

		collection = db.Collection("business")
		rows, err = collection.Find(ctx, bson.M{"_id": bson.M{"$in": ids}, "IsEnabled": true})
		defer rows.Close(ctx)
		if err == mongo.ErrNoDocuments {
			return response, nil
		}
		if err != nil {
			return nil, stacktrace.Propagate(err, "")
		}

		for rows.Next(ctx) {
			var business models.BusinessExt
			err = rows.Decode(&business.Business)
			if err != nil {
				return nil, stacktrace.Propagate(err, "")
			}

			phone, err := libphonenumber.Parse(business.Phone, "US")
			if err != nil {
				return nil, stacktrace.Propagate(err, "")
			}

			business.Phone = libphonenumber.Format(phone, libphonenumber.NATIONAL)

			response = append(response, business)
		}

		for i := range response {
			for t := range jobs {

				alreadyApplied := false
				for d := range jobs[t].Applicants {
					currentApplicant := &jobs[t].Applicants[d]
					if currentApplicant.UserId.Hex() == req.IdUser {
						alreadyApplied = true
					}
				}

				if response[i].Id.Hex() == jobs[t].BusinessId.Hex() && !alreadyApplied {
					response[i].Listings = append(response[i].Listings, jobs[t])
				}
			}
		}
	}

	return response, nil
}
